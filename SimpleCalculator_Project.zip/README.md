# Simple Calculator (Java)

## 📌 About the Project  
I am from a **Mechanical Engineering** background and created this program **purely for practice and learning Java basics**.  
This is a simple **console-based calculator** that performs addition, subtraction, multiplication, and division based on user input.  

## 🛠 Features  
- Takes two numbers from the user  
- Supports basic arithmetic operations (+, -, *, /)  
- Displays the calculated result in the console  

## 💻 Technologies Used  
- **Java** (Core)  
- **Scanner** class for input handling  

## 🚀 How to Run  
1. Save the file as `SimpleCalculator.java`  
2. Open terminal in the file directory  
3. Compile the file:  
   ```bash
   javac SimpleCalculator.java
   ```
4. Run the program:  
   ```bash
   java SimpleCalculator
   ```
